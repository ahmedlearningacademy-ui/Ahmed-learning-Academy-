-- Run this in Supabase SQL Editor AFTER reviewing it.
-- It creates student profiles and payment requests with RLS.
-- IMPORTANT: This does NOT create an admin. Bootstrap the first admin only from a trusted server-side process.

create type public.app_role as enum ('student', 'admin');
create type public.payment_status as enum ('pending', 'approved', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  role public.app_role not null default 'student',
  created_at timestamptz not null default now()
);

create table public.payment_requests (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  amount integer not null check (amount = 299),
  currency text not null default 'EGP' check (currency = 'EGP'),
  receipt_path text,
  transfer_reference text,
  status public.payment_status not null default 'pending',
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  payment_request_id uuid unique references public.payment_requests(id),
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index payment_requests_student_id_idx on public.payment_requests(student_id);
create index subscriptions_student_id_idx on public.subscriptions(student_id);

-- Create profile automatically for every new signup. Public signups are always students.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'student');
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.payment_requests enable row level security;
alter table public.subscriptions enable row level security;

-- Students can read/update only their own limited profile fields. Role is not client-editable.
create policy "profiles read own" on public.profiles
for select to authenticated
using (id = (select auth.uid()));

create policy "students update own basic profile" on public.profiles
for update to authenticated
using (id = (select auth.uid()) and role = 'student')
with check (id = (select auth.uid()) and role = 'student');

create policy "students create own payment requests" on public.payment_requests
for insert to authenticated
with check (student_id = (select auth.uid()) and status = 'pending' and reviewed_by is null and reviewed_at is null and amount = 299 and currency = 'EGP');

create policy "students read own payments or admin" on public.payment_requests
for select to authenticated
using (student_id = (select auth.uid()));

create policy "students read own subscriptions or admin" on public.subscriptions
for select to authenticated
using (student_id = (select auth.uid()));

-- Deliberately no client-side policies for changing roles, approving payments, or creating subscriptions.
-- Those actions must be implemented in a server-side Edge Function that verifies admin role.

-- Private bucket for receipts. Upload paths must start with the authenticated user's UUID.
insert into storage.buckets (id, name, public)
values ('payment-receipts', 'payment-receipts', false)
on conflict (id) do nothing;

create policy "students upload own receipt files" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'payment-receipts'
  and (storage.foldername(name))[1] = (select auth.uid())::text
);

create policy "students read own receipt files or admin" on storage.objects
for select to authenticated
using (
  bucket_id = 'payment-receipts'
  and (
    (storage.foldername(name))[1] = (select auth.uid())::text
    
  )
);
