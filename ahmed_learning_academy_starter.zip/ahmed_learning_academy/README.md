# AHMED LEARNING ACADEMY — connected starter

This is the first working website foundation, connected to the Supabase project URL and publishable key supplied by the owner.

## Run locally

Because the app uses JavaScript modules, serve this folder with a static web server (do not open `index.html` directly as a `file://` URL). For example:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Supabase setup

1. In Supabase Dashboard, open **Authentication → URL Configuration**. Add your local URL and your eventual Cloudflare Pages URL to the allowed redirect URLs.
2. Open **SQL Editor** and review/run `supabase/schema.sql`.
3. In **Authentication → Providers → Email**, enable email signups and email confirmation.
4. Configure SMTP before production if you need reliable branded confirmation and reset emails.
5. Bootstrap the first admin only through a trusted server-side process. Do not make a public “become admin” page and do not update the `role` field from the browser.
6. Add a server-side Edge Function for admin payment approval; it must verify the signed-in user's admin role, verify the payment is pending, then atomically mark it approved and create a 30-day subscription. The browser must never receive the service-role/secret key.

## Security notes

- The Supabase publishable key is intended to be present in browser code. It is not an admin credential.
- Never put a Supabase secret/service-role key, database password, personal access token, bank password, or OTP in this project or chat.
- RLS policies are included for the initial profile, payment request, subscription, and private receipt-storage foundation. Test them with separate student and admin accounts before accepting real students or payments.
- The first admin is intentionally NOT created by this SQL file. A trusted bootstrap step is required to avoid anyone claiming the first-admin role.

## Current scope

Included: academy landing page, Supabase email/password signup, sign-in, email confirmation flow, password reset request, sign-out, initial RLS schema.

Not yet included: admin dashboard, secure admin bootstrap/Edge Function, payment receipt upload UI, payment approval workflow, lesson content management, course lessons/PDF/video content, assessments, certificates, and production SMTP configuration. Do not advertise these as active until implemented and tested.
