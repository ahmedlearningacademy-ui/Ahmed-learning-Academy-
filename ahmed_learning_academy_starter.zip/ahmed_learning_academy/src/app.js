import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './config.js';

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
});
const $ = (id) => document.getElementById(id);
let mode = 'signin';
$('year').textContent = new Date().getFullYear();

function message(text, isError = false) {
  $('status').textContent = text;
  $('status').className = `status ${isError ? 'error' : 'success'}`;
}
function setMode(next) {
  mode = next;
  $('auth-title').textContent = mode === 'signup' ? 'Create your student account' : 'Sign in to your account';
  $('auth-submit').textContent = mode === 'signup' ? 'Create student account' : 'Sign in';
  $('toggle-auth').textContent = mode === 'signup' ? 'Already registered? Sign in' : 'Create a student account';
  $('password').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
  message('');
}
function showAccount(session) {
  const signedIn = !!session;
  $('signout').classList.toggle('hidden', !signedIn);
  $('auth-form').classList.toggle('hidden', signedIn);
  $('auth-links').classList.toggle('hidden', signedIn);
  if (signedIn) {
    $('auth-title').textContent = 'You are signed in';
    $('auth-message').textContent = `Signed in as ${session.user.email}. Your account is a student account. Admin access is assigned separately and cannot be selected during registration.`;
  } else {
    setMode('signin');
    $('auth-message').textContent = 'Create a student account or sign in to continue.';
  }
}

$('open-auth').addEventListener('click', () => $('account').scrollIntoView({ behavior: 'smooth' }));
$('hero-signup').addEventListener('click', () => { setMode('signup'); $('account').scrollIntoView({ behavior: 'smooth' }); });
$('pricing-signup').addEventListener('click', () => { setMode('signup'); $('account').scrollIntoView({ behavior: 'smooth' }); });
$('toggle-auth').addEventListener('click', () => setMode(mode === 'signup' ? 'signin' : 'signup'));
$('auth-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const email = $('email').value.trim();
  const password = $('password').value;
  $('auth-submit').disabled = true;
  try {
    if (mode === 'signup') {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${location.origin}/` } });
      if (error) throw error;
      message(data.session ? 'Account created. You are signed in.' : 'Account created. Check your email to confirm your address before signing in.');
      if (data.session) showAccount(data.session);
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      showAccount(data.session);
      message('Signed in successfully.');
    }
  } catch (error) { message(error.message || 'Something went wrong.', true); }
  finally { $('auth-submit').disabled = false; }
});
$('reset-password').addEventListener('click', async () => {
  const email = $('email').value.trim();
  if (!email) return message('Enter your email address first.', true);
  const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/` });
  message(error ? error.message : 'If this email is registered, a password reset link has been sent.');
});
$('signout').addEventListener('click', async () => {
  const { error } = await supabase.auth.signOut();
  if (error) return message(error.message, true);
  showAccount(null); message('Signed out.');
});
supabase.auth.onAuthStateChange((_event, session) => showAccount(session));
supabase.auth.getSession().then(({ data }) => showAccount(data.session));
