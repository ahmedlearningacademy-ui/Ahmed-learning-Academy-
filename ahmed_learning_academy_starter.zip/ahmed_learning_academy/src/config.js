// Supabase browser configuration. The publishable key is designed for public clients.
// Database security MUST be enforced with Row Level Security (see ../supabase/schema.sql).
export const SUPABASE_URL = 'https://czhfvdxbbddmodhkwyla.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_ShIcGZr5Km23rFfUcCjfRQ_ZMxjN_pH';
